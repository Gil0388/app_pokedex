import 'package:flutter/material.dart';

Color blue = Colors.blue.shade700;
const Color white = Colors.white;
const IconThemeData iconTheme = IconThemeData(color: white);
const TextStyle titleTextStyle = TextStyle(fontSize: 20, color: white);
const String pokeballLink =
    'https://raw.githubusercontent.com/RafaelBarbosatec/SimplePokedex/master/assets/pokebola_img.png';
